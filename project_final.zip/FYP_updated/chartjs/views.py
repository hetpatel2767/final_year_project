from django.shortcuts import render
from django.views.generic import View

from rest_framework.views import APIView
from rest_framework.response import Response


class HomeView(View):
    def get(self, request, *args, **kwargs):
        return render(request, 'chartjs/index.html')


class ChartData(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request, format=None):
        labels = [
            'January',
            'February',
            'March',
            'April',
            'May',
            'June',
            'July',
            'August',
            'September',
            'October',
            'November',
            'December'
        ]
        chartLabel1 = "Grocery Sales Data"
        chartLabel2 = "Total  Item Sold"
        chartdata = [0, 10, 5, 2, 20, 30, 45, 1, 15, 23, 12, 10]
        data = {
            "labels": labels,
            "chartLabel1": chartLabel1,
            "chartLabel2": chartLabel2,
            "chartdata": chartdata,
        }
        return Response(data)
