-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2021 at 02:01 PM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.1.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grocery`
--

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `cId` int(10) NOT NULL,
  `cName` text NOT NULL,
  `cEmail` varchar(100) NOT NULL,
  `cSubject` varchar(150) NOT NULL,
  `cMessage` varchar(1000) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`cId`, `cName`, `cEmail`, `cSubject`, `cMessage`, `time`) VALUES
(1, 'Harsh Patel', 'hp@gmail.com', 'xyz', 'xyz', '2021-03-13 23:04:45'),
(2, 'Hunter Hp', 'hp123@gmail.com', 'xyz abc', 'abc xyz', '2021-03-13 23:08:54'),
(3, 'Heloooo', 'hpppp1@gmail.com', 'hsh hhahsh s', 'i dshdh i his dh ahd hshd hdhsdhsd hdsh hdhd jcxjcbjvcbvcjxvbcxvbcbvcxbvbhxcvbcbvcbvbcnvcbvcbnvbncvc bnvcbnvbnc  bn bnc nbv bn bnc    cv   bnv bnc vcv c', '2021-03-27 10:25:02');

-- --------------------------------------------------------

--
-- Table structure for table `details`
--

CREATE TABLE `details` (
  `id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mainCatId` int(10) NOT NULL,
  `catId` int(10) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `details`
--

INSERT INTO `details` (`id`, `name`, `mainCatId`, `catId`, `time`) VALUES
(1, 'Nuts', 1, 1, '0000-00-00 00:00:00'),
(2, 'Oil', 2, 1, '2021-03-12 14:34:39'),
(3, 'Pastas & Noodles', 3, 1, '2021-03-12 14:47:57');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `itemId` int(10) NOT NULL,
  `mainCatId` int(10) NOT NULL,
  `catId` int(10) NOT NULL,
  `itemName` varchar(100) NOT NULL,
  `itemOriPrice` int(10) NOT NULL,
  `itemPrice` int(10) NOT NULL,
  `itemType` varchar(50) NOT NULL,
  `itemImage` varchar(1000) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`itemId`, `mainCatId`, `catId`, `itemName`, `itemOriPrice`, `itemPrice`, `itemType`, `itemImage`, `time`) VALUES
(1, 1, 1, 'Almonds, 100g', 280, 149, 'Vegetarian', 'images/m1.jpg', '2021-03-12 14:16:35'),
(2, 1, 1, 'Cashew Nuts, 100g', 420, 200, 'Vegetarian', 'images/m2.jpg', '2021-03-12 14:17:32'),
(3, 2, 1, 'Freedom Oil, 1L', 110, 78, 'Vegetarian', 'images/mk4.jpg', '2021-03-12 14:35:42'),
(4, 2, 1, 'Suffola Gold,1L', 150, 130, 'Vegetarian', 'images/mk5.jpg', '2021-03-12 14:36:33'),
(5, 2, 1, 'Fortune Oil, 5L', 500, 399, 'Vegetarian', 'images/mk6.jpg', '2021-03-12 14:37:20'),
(6, 1, 1, 'Pista, 250g', 601, 521, 'Vegetarian', 'images/m3.jpg', '2021-03-12 14:41:09'),
(8, 3, 1, 'Yippee Noodles, 65g', 25, 15, 'Vegetarian', 'images/mk7.jpg', '2021-03-12 14:48:50'),
(9, 3, 1, 'Wheat Pasta, 500g', 120, 98, 'Vegetarian', 'images/mk8.jpg', '2021-03-12 14:49:33'),
(10, 3, 1, 'Chinese Noodles, 68g', 15, 12, 'Vegetarian', 'images/mk9.jpg', '2021-03-12 14:50:07');

-- --------------------------------------------------------

--
-- Table structure for table `specialproducts`
--

CREATE TABLE `specialproducts` (
  `itemId` int(10) NOT NULL,
  `itemName` varchar(100) NOT NULL,
  `itemPrice` int(10) NOT NULL,
  `savePrice` int(10) NOT NULL,
  `itemType` varchar(50) NOT NULL,
  `itemImage` varchar(1000) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specialproducts`
--

INSERT INTO `specialproducts` (`itemId`, `itemName`, `itemPrice`, `savePrice`, `itemType`, `itemImage`, `time`) VALUES
(1, 'Aashirvaad, 5g', 220, 40, 'Vegetarian', 'images/s1.jpg', '2021-03-12 14:57:42'),
(2, 'Kissan Tomato Ketchup, 950g', 99, 20, 'Vegetarian', 'images/s4.jpg', '2021-03-12 14:58:25'),
(3, 'Madhur Pure Sugar, 1kg', 69, 20, 'Vegetarian', 'images/s2.jpg', '2021-03-12 14:59:11'),
(4, 'Surf Excel Liquid, 1.02L', 187, 30, 'Vegetarian', 'images/s3.jpg', '2021-03-12 15:00:36'),
(5, 'Cadbury Choclairs, 655.5g', 160, 60, 'Vegetarian', 'images/s8.jpg', '2021-03-12 15:01:15'),
(6, 'Fair & Lovely, 80 g', 122, 30, 'Vegetarian', 'images/s6.jpg', '2021-03-12 15:02:11'),
(7, 'Sprite, 2.25L (Pack of 2)', 180, 30, 'Vegetarian', 'images/s5.jpg', '2021-03-12 15:02:47'),
(8, 'Lakme Eyeconic Kajal, 1.35 g', 153, 40, 'Vegetarian', 'images/s9.jpg', '2021-03-12 15:03:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(10) NOT NULL,
  `userName` varchar(100) NOT NULL,
  `userEmail` varchar(100) NOT NULL,
  `userPassword` varchar(100) NOT NULL,
  `time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userPassword`, `time`) VALUES
(7, 'Harsh Patel', 'hrspatel@gmail.com', '123', '2021-03-13 11:07:20'),
(8, 'Patel Saheb', 'hp@gmail.com', '123', '2021-03-13 16:44:02'),
(9, 'Hunter HP', 'hp1@gmail.com', '12345', '2021-03-13 16:45:14'),
(10, 'Hunetetree', 'apap@gmail.com', '123', '2021-03-27 10:59:46'),
(11, 'hsasb  as as', 'wer@gmail.com', '123', '2021-03-27 11:03:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`cId`);

--
-- Indexes for table `details`
--
ALTER TABLE `details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`itemId`);

--
-- Indexes for table `specialproducts`
--
ALTER TABLE `specialproducts`
  ADD PRIMARY KEY (`itemId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `cId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `details`
--
ALTER TABLE `details`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `itemId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `specialproducts`
--
ALTER TABLE `specialproducts`
  MODIFY `itemId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
