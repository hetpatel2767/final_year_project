from django.contrib import admin
from django.urls import path
from shop import views

urlpatterns = [
    path("home/", views.home, name='home'),
    # path('base/', views.base, name='base'),
    path('about/', views.About, name='about'),
    path('productDetails/', views.productDetails, name='productDetail'),
    path('specialProductDetails/',
         views.specialProductDetails, name='specialProduct'),
    path('contact/', views.contact, name='contact'),
    path('faqs/', views.faqs, name='faqs'),
    path('help/', views.help, name='help'),
    path('terms/', views.terms, name='terms'),
    path('privacy', views.privacy, name='privacy'),
    path('payment/', views.payment, name='payment'),
    path('checkout/', views.checkout, name='checkout'),
    path('auth/', views.auth, name='auth'),
    path('signin/', views.signin, name='signin'),
    path('signout', views.signout, name='signout'),
    path('home/checkout.html', views.checkout, name='check'),
    path('register/', views.RegistraionView.as_view(), name='register'),
    path('activate/<uidb64>/<token>',
         views.AccountActivateView.as_view(), name='activate'),
    path('webIcons/', views.webIcons, name='webicons'),
    path('typography/', views.typography, name='typography'),
    path('newUserEmail/', views.newUserEmail, name='newuseremail'),
    path('searchedProducts/', views.SearchedProduct, name='searchProduct'),

    path('isearch/', views.upload, name='upload'),
]
