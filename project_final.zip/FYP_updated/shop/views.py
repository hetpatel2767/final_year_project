from botocore.config import Config
import boto3
from django.shortcuts import render, render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import HttpResponse
from .utils import generate_token
from os import curdir
from django.contrib.messages.api import add_message
from django.shortcuts import render, redirect
from django.views.generic import View
from django.contrib import messages
from validate_email import validate_email
from django.contrib.auth.models import User
# to get current domain
from django.utils.http import int_to_base36
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
# to get uid
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_bytes, force_text, DjangoUnicodeDecodeError
from .utils import generate_token
#from django.contrib.auth.tokens import PasswordResetTokenGenerator
from django.core.mail import EmailMessage
from django.conf import settings
import mysql.connector
import smtplib
from django.views.generic import TemplateView
from django.core.files.storage import FileSystemStorage

GML_ID = "communityhrsjp@gmail.com"
GML_PWD = "Hrsjp@community@..123"

image_name = ''


def sendMail(email):
    mail = smtplib.SMTP("smtp.gmail.com", 587)
    mail.starttls()
    mail.login(GML_ID, GML_PWD)
    mess = f"Subject:Congratulation!!\n\nYou are subscribed for new GIFT."
    mail.sendmail(GML_ID, email, mess)
    mail.quit()


mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="grocery"
)
# Create your views here.

# Create your views here.

# for authenication


def auth(request):
    if request.user.is_anonymous:
        return redirect('/signin')
    else:
        context = {'status': 'Log Out'}
        return render(request, 'index.html', context)


def home(request):
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM `items`")
    myresult = mycursor.fetchall()
    mycursor.execute("SELECT * FROM `specialproducts`")
    myresult1 = mycursor.fetchall()

    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth',
                   'items': myresult, 'sItems': myresult1}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout',
                   'items': myresult, 'sItems': myresult1}  # for signout
    return render(request, 'index.html', context)


def productDetails(request):
    prodId = request.GET.get('productId')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM `specialproducts`")
    myresult1 = mycursor.fetchall()
    sql = "SELECT * FROM `items` WHERE itemId="+prodId
    mycursor.execute(sql)
    myresult = mycursor.fetchall()
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth',
                   'sItems': myresult1, 'product': myresult[0]}
    else:
        context = {'status': 'Sign Out', 'action': '/signout',
                   'sItems': myresult1, 'product': myresult[0]}
    return render(request, 'product.html', context)


def specialProductDetails(request):
    prodId = request.GET.get('productId')
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM `specialproducts`")
    myresult1 = mycursor.fetchall()
    sql = "SELECT * FROM `specialproducts` WHERE itemId="+prodId
    mycursor.execute(sql)
    myresult = mycursor.fetchall()
    print(myresult)
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth',
                   'sItems': myresult1, 'product': myresult[0]}
    else:
        context = {'status': 'Sign Out', 'action': '/signout',
                   'sItems': myresult1, 'product': myresult[0]}
    return render(request, 'product2.html', context)


def About(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'about.html', context)


def contact(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'contact.html', context)


def faqs(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'faqs.html', context)


def help(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'help.html', context)


def payment(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'payment.html', context)


def checkout(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'checkout.html', context)


def terms(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'terms.html', context)


def privacy(request):
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth'}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout'}  # for signout
    return render(request, 'privacy.html', context)


def signin(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
        user = authenticate(username=username, password=password)
        if user is not None:
            # A backend authenticated the credentials,password= UserisBot
            login(request, user)
            #messages.info( request, 'Your password has been changed successfully!')
            return redirect('/home')
        else:
            # No backend authenticated the credentials

            return render(request, 'auth.html')

    return render(request, "auth.html")


def signout(request):
    logout(request)
    return redirect('/home')


class RegistraionView(View):
    def get(self, request):
        return render(request, 'register.html')

    def post(self, request):
        email = request.POST.get('email')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        username = request.POST.get('username')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')

        # print(email,first_name,last_name,username,password1,password2)
        context = {
            'data': request.POST,
            'has_error': False
        }
        if password1 != password2:
            messages.add_message(request, messages.ERROR,
                                 'password does not matach')
            context['has_error'] = True

        # if len(password1)>6:
        #     messages.add_message(request,messages.ERROR,'password too short, minumum 6 character required')
        #     context['has_error'] = True

        if len(password1) == 0:
            messages.add_message(request, messages.ERROR, 'Choose Password')
            context['has_error'] = True

        if not validate_email(email):
            messages.add_message(request, messages.ERROR,
                                 'Provide Valid Email')
            context['has_error'] = True

        if User.objects.filter(email=email).exists():
            messages.add_message(request, messages.ERROR,
                                 'Email ID is already taken')
            context['has_error'] = True

        if User.objects.filter(username=username).exists():
            messages.add_message(request, messages.ERROR,
                                 'Username is already taken')
            context['has_error'] = True

        if context['has_error']:
            return render(request, 'register.html', context, status=400)
        else:
            user = User.objects.create_user(
                username=username, email=email, first_name=first_name, last_name=last_name, is_active=True)
            '''current_site = get_current_site(request)
            email_subject = 'Activation Email!'
            message = render_to_string('activatetemplate.html', {
                'username': user,
                'domain': current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': generate_token.make_token(user)
            })'''
            user.set_password(password1)
            user.save()

            '''email_message = EmailMessage(
                email_subject,
                message,
                settings.EMAIL_HOST_USER,
                [email]
            )
            email_message.send()
            user.set_password(password1)
            user.first_name = first_name
            user.last_name = last_name
            
            messages.add_message(request, messages.SUCCESS,
                                 'Account is Created!')'''
            return redirect('signin')


class AccountActivateView(View):
    def get(self, request, uidb64, token):
        try:
            uid = force_text(urlsafe_base64_decode(uidb64))
            user = User.objects.get(pk=uid)
        except Exception as identifier:
            user = None

        if user is not None and generate_token.check_token(user, token):
            user.is_active = True
            user.save()
            messages.add_message(request, messages.INFO,
                                 'Account is Activated')
            return redirect('signin')
        return render(request, 'activate_failed.html', status=401)


def webIcons(request):
    return render(request, 'icons.html')


def typography(request):
    return render(request, 'typography.html')


def newUserEmail(request):
    em = request.POST.get('email')
    sendMail(em)
    mycursor = mydb.cursor()
    mycursor.execute("SELECT * FROM `items`")
    myresult = mycursor.fetchall()
    mycursor.execute("SELECT * FROM `specialproducts`")
    myresult1 = mycursor.fetchall()

    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth',
                   'items': myresult, 'sItems': myresult1}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout',
                   'items': myresult, 'sItems': myresult1}  # for signout
    return render(request, 'index.html', context)


def SearchedProduct(request):
    word = request.GET.get('searchedWord')
    mycursor = mydb.cursor()
    sql = "SELECT * FROM `items` WHERE itemName LIKE '%" + \
        word+"%' or itemType LIKE '%"+word+"%'"
    mycursor.execute(sql)
    myresult = mycursor.fetchall()
    lenth = len(myresult)
    mycursor.execute("SELECT * FROM `specialproducts`")
    myresult1 = mycursor.fetchall()
    print(myresult1)
    if request.user.is_anonymous:
        context = {'status': 'Sign In', 'action': '/auth', 'lenth': lenth,
                   'items': myresult, 'sItems': myresult1}  # for signin
    else:
        context = {'status': 'Sign Out', 'action': '/signout', 'lenth': lenth,
                   'items': myresult, 'sItems': myresult1}  # for signout
    return render(request, 'search.html', context)


class Home(TemplateView):
    template_name = 'index.html'


def upload(request):
    global image_name
    context = {}
    if request.method == 'POST':
        uploaded_file = request.FILES['document']
        fs = FileSystemStorage()
        name = fs.save(uploaded_file.name, uploaded_file)
        context['url'] = fs.url(name)
        # print(fs.url(name))
        image_name = fs.url(name)[1:]
        photo = image_name

        label = detect_labels_local_file(photo)
        print("Labels detected: " + str(label['Name']))
        word = str(label['Name'])
        mycursor = mydb.cursor()
        sql = "SELECT * FROM `items` WHERE itemName LIKE '%" + \
            word+"%' or itemType LIKE '%"+word+"%'"
        mycursor.execute(sql)
        myresult = mycursor.fetchall()
        lenth = len(myresult)
        if request.user.is_anonymous:
            context = {'lenth': lenth,
                       'items': myresult, }  # for signin
        else:
            context = {'lenth': lenth,
                       'items': myresult, }  # for signout
        return render(request, 'search.html', context)

    return render(request, 'upload.html', context)


###############################################################

access_key_id = 'AKIA6MXYYETK7ODMGVKF'
secret_access_key = '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'


def detect_labels_local_file(photo):
    my_config = Config(
        region_name='us-west-2',
        retries={
            'max_attempts': 10,
            'mode': 'standard'
        }
    )

    client = boto3.client('rekognition',  aws_access_key_id=access_key_id,
                          aws_secret_access_key=secret_access_key, config=my_config)

    with open(photo, 'rb') as image:
        response = client.detect_labels(Image={'Bytes': image.read()})

    print('Detected labels in ' + photo)
    l = list()
    for label in response['Labels']:
        print(label['Name'] + ' : ' + str(label['Confidence']))
        l.append(label)

    return l[0]


# def main():


# if __name__ == "__main__":
 #   main()
