import boto3
from botocore.config import Config

access_key_id = 'AKIA6MXYYETK7ODMGVKF'
secret_access_key = '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'


def detect_labels_local_file(photo):
    my_config = Config(
        region_name='us-west-2',
        retries={
            'max_attempts': 10,
            'mode': 'standard'
        }
    )

    client = boto3.client('rekognition',  aws_access_key_id=access_key_id,
                          aws_secret_access_key=secret_access_key, config=my_config)

    with open(photo, 'rb') as image:
        response = client.detect_labels(Image={'Bytes': image.read()})

    print('Detected labels in ' + photo)
    for label in response['Labels']:
        print(label['Name'] + ' : ' + str(label['Confidence']))

    return len(response['Labels'])


def main():
    photo = 'media\oDh2aBTkP5md9yoQLW7js.jpg'

    label_count = detect_labels_local_file(photo)
    print("Labels detected: " + str(label_count))


if __name__ == "__main__":
    main()
